package com.imooc.mvcdemo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/firefly")
public class FireFlyMvcController {

	@RequestMapping("/mvc")
	// host:8080/firefly/mvc
	public String fireFlyMvc() {
		//yingbao.jsp
		return "yingbao";
	}
	
}
